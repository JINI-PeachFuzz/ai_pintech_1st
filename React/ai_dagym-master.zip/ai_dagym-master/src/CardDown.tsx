import FreeContents from "./FreeContents";

const CardDown = () => {
  return (
    <div>
      <FreeContents
        services={"샤워실/수건/대형제빙기/무료주차쌉가능/인바디 공개처형"}
      />
    </div>
  );
};

export default CardDown;
