import DagymLayout from "./DagymLayout";

function App() {
  return (
    <div>
      <DagymLayout />
    </div>
  );
}

export default App;
